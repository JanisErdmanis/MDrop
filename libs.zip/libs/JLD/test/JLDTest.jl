module JLDTest

export Object

type Object
    data::Int16
end

end
