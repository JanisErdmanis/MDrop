Installation and Version Requirements
=====================================

To install ForwardDiff.jl, simply use Julia's package manager:

.. code-block:: julia

    julia> Pkg.add("ForwardDiff")

The current version of ForwardDiff.jl only supports Julia v0.4.