
#ifndef CCD_DEFS_H
#define CCD_DEFS_H

//
// Uncomment one of the following to select the continuous collision detection method.
//

#define USE_CUBIC_SOLVER_CCD
//#define USE_ROOT_PARITY_CCD

#endif
