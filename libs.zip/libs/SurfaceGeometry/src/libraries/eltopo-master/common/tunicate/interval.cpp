// ---------------------------------------------------------
//
//  interval.cpp
//  Tyson Brochu 2011
//
//  Function definitions for switching rounding modes.
//
// ---------------------------------------------------------

#include <interval.h>

int Interval::s_previous_rounding_mode = ~0;


