using Base.Test
using FastGaussQuadrature

include("test_gausslegendre.jl")
include("test_gaussjacobi.jl")
include("test_gaussradau.jl")
include("test_gausslobatto.jl")
